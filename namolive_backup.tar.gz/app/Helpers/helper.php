<?php

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use App\Models\AdminLogin;
use App\Models\RolePermission;
use Log;

function fetchFyersHistoricalData($symbol, $fromDate, $toDate, $resolution = 1)
{
    $data = \DB::table('fyers')->first();
    $url = "https://api-t1.fyers.in/data/history";

    $queryParams = [    
        'symbol' => $symbol,
        'resolution' => $resolution,
        'date_format' => 1,
        'range_from' => $fromDate,
        'range_to' => $toDate,
        'cont_flag' => 1,
    ];

       $token = $data->FYERS_CLIENT_ID.':'.$data->FYERS_ACCESS_TOKEN;

    try {
        $response = Http::withHeaders([
            'Authorization' => $token
        ])->get($url, $queryParams);

        if ($response->successful()) {
            return $response->json();
        } else {
            return [
                'error' => true,
                'status' => $response->status(),
                'message' => $response->body()
            ];
        }
    } catch (\Exception $e) {
        return [
            'error' => true,
            'message' => $e->getMessage()
        ];
    }
    Log::info('heating from helper 1');
}



function fetchFyersQuotes(array $symbols)
{
    $url = "https://api-t1.fyers.in/data/quotes";
     $data = \DB::table('fyers')->first();

    $queryParams = [
        'symbols' => implode(',', $symbols),
    ];

 $token = $data->FYERS_CLIENT_ID.':'.$data->FYERS_ACCESS_TOKEN;
    // dd($token);
    try {
        $response = Http::withHeaders([
            'Authorization' => $token
        ])->get($url, $queryParams);

        if ($response->successful()) {
            return $response->json();
        } else {
            return [
                'error' => true,
                'status' => $response->status(),
                'message' => $response->body()
            ];
        }
    } catch (\Exception $e) {
        return [
            'error' => true,
            'message' => $e->getMessage()
        ];
    }
    Log::info('heating from helper 2');
}


function canAccess($permission)
{
    // Check if admin is logged in
    if (!Session::has('admin_id')) {
        return false;
    }

    // Get user with role relationship
    $user = AdminLogin::with('role')->find(Session::get('admin_id'));

    // Check if user exists and has a role
    if (!$user || !$user->role) {
        return false;
    }

    // If user is Admin, grant all permissions
    if ($user->role->name == 'Admin') {
        return true;
    }

    // Get permissions for the user's actual role
    $permissions = RolePermission::join('permissions', 'permissions.id', 'role_permissions.permission_id')
        ->where('role_permissions.role_id', $user->role->id) // Use user's role_id, not hard-coded
        ->pluck('permissions.name')
        ->toArray();

    return in_array($permission, $permissions);
}



